# Real-Time Object Detection in C# (Stub)

A C# WinForms (or console) project stub to do real-time object detection from a webcam.
This scaffold uses OpenCvSharp for webcam frames.  
To actually detect objects, connect to an ONNX model or TensorFlow export for .NET.

## Features
- Grabs webcam frames using OpenCvSharp
- Scaffold for calling AI/ONNX/TensorFlow model (stub)
- Extendable to show bounding boxes, etc.

## Requirements
- .NET 6 SDK (or .NET Framework)
- [OpenCvSharp4](https://github.com/shimat/opencvsharp) NuGet package
- ONNX object detection model (optional for now)

## Usage
1. Install OpenCvSharp4:  
   `dotnet add package OpenCvSharp4`
2. Build & run:  
   `dotnet run`
3. Extend with object detection logic (see ModelRunner.cs).

## Note
- For a full app, add model inference (ONNX, ML.NET, etc.) in ModelRunner.
