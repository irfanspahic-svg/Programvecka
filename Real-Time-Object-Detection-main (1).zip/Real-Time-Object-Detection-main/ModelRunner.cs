using OpenCvSharp;

namespace CSObjectDetection
{
    public static class ModelRunner
    {
        public static void Run(Mat frame)
        {
            // Stub: Add object detection logic here (ONNX, ML.NET, etc.)
            // For now, just pass through.
        }
    }
}
