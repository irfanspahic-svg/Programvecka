using System;
using OpenCvSharp;

namespace CSObjectDetection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting webcam (press ESC to exit)...");

            using var capture = new VideoCapture(0);
            using var window = new Window("Webcam");

            var image = new Mat();
            while (true)
            {
                capture.Read(image);
                if (image.Empty()) continue;

                // TODO: Run object detection here
                // ModelRunner.Run(image);

                window.ShowImage(image);

                int key = Cv2.WaitKey(30);
                if (key == 27) break; // ESC to exit
            }
        }
    }
}
